#!/bin/bash

# XRAY IP Limiter v3.1 - FINAL: Proper blocking without duplication

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

XRAY_CONFIG="/etc/xray/config.json"
LOCK_DIR="/var/lib/xray-iplimit"
LOCK_FILE="${LOCK_DIR}/locked_users.txt"
BACKUP_DIR="${LOCK_DIR}/backups"
USER_UUID_MAP="${LOCK_DIR}/user_uuid_map.txt"
IP_SESSIONS="${LOCK_DIR}/ip_sessions.txt"
LIMIT_CONFIG="${LOCK_DIR}/user_limits.conf"
LOG_FILE="/var/log/xray/iplimit.log"

DEFAULT_LOCK_MINUTES=30
DEFAULT_MAX_IP=2

mkdir -p "$LOCK_DIR" "$BACKUP_DIR"
touch "$LOCK_FILE" "$USER_UUID_MAP" "$IP_SESSIONS" "$LIMIT_CONFIG" "$LOG_FILE"

log_msg() {
    echo -e "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

get_user_limit() {
    local user="$1"
    local limit=$(grep "^${user}:" "$LIMIT_CONFIG" | cut -d: -f2)
    [ -z "$limit" ] && echo "$DEFAULT_MAX_IP" || echo "$limit"
}

get_lock_duration() {
    local user="$1"
    local duration=$(grep "^${user}:" "$LIMIT_CONFIG" | cut -d: -f3)
    [ -z "$duration" ] && echo "$DEFAULT_LOCK_MINUTES" || echo "$duration"
}

is_user_locked() {
    local user="$1"
    local current_time=$(date +%s)
    
    if grep -q "^${user}:" "$LOCK_FILE"; then
        local lock_until=$(grep "^${user}:" "$LOCK_FILE" | cut -d: -f2)
        if [ "$current_time" -lt "$lock_until" ]; then
            return 0
        else
            sed -i "/^${user}:/d" "$LOCK_FILE"
        fi
    fi
    return 1
}

lock_user() {
    local user="$1"
    local lock_minutes=$(get_lock_duration "$user")
    local lock_until=$(($(date +%s) + (lock_minutes * 60)))
    
    sed -i "/^${user}:/d" "$LOCK_FILE"
    echo "${user}:${lock_until}" >> "$LOCK_FILE"
    
    log_msg "${RED}[LOCKED]${NC} User '${user}' locked for ${lock_minutes} minutes (until $(date -d @$lock_until '+%H:%M:%S'))"
}

block_user_in_xray() {
    local user="$1"
    
    # Check if already blocked
    if grep -q "#LOCKED_.*${user}" "$XRAY_CONFIG"; then
        log_msg "${YELLOW}[INFO]${NC} User '${user}' already blocked in config"
        return 0
    fi
    
    # Backup config
    local backup_file="${BACKUP_DIR}/config_$(date +%Y%m%d_%H%M%S).json"
    cp "$XRAY_CONFIG" "$backup_file"
    log_msg "${BLUE}[BACKUP]${NC} Config backed up to: $backup_file"
    
    # Get user's UUID
    local uuid=$(grep "email.*${user}" "$XRAY_CONFIG" | grep -oP '(?<="id": ")[^"]+' | head -1)
    
    if [ -z "$uuid" ]; then
        # Try password field for trojan
        uuid=$(grep -B 2 "email.*${user}" "$XRAY_CONFIG" | grep "password" | grep -oP '(?<="password": ")[^"]+' | head -1)
    fi
    
    if [ -z "$uuid" ]; then
        log_msg "${RED}[ERROR]${NC} Cannot find UUID for user '${user}'"
        return 1
    fi
    
    log_msg "${YELLOW}[BLOCKING]${NC} UUID: ${uuid:0:8}...${uuid: -8}"
    
    # Create temporary file
    local temp_file="/tmp/xray_config_$$.json"
    cp "$XRAY_CONFIG" "$temp_file"
    
    # Comment out ALL lines containing the email (avoid duplication)
    sed -i "/.*${user}.*/s/^[^#]/#LOCKED_&/" "$temp_file"
    
    # Also comment out lines with the UUID (avoid duplication)
    sed -i "/.*${uuid}.*/s/^[^#]/#LOCKED_&/" "$temp_file"
    
    # Move temp to config
    mv "$temp_file" "$XRAY_CONFIG"
    
    # Restart XRAY
    systemctl restart xray > /dev/null 2>&1
    sleep 2
    
    # Verify XRAY is running
    if systemctl is-active --quiet xray; then
        log_msg "${GREEN}[SUCCESS]${NC} User '${user}' blocked, XRAY restarted successfully"
        return 0
    else
        log_msg "${RED}[CRITICAL]${NC} XRAY failed to start! Restoring backup..."
        cp "$backup_file" "$XRAY_CONFIG"
        systemctl restart xray
        return 1
    fi
}

unblock_user_in_xray() {
    local user="$1"
    
    # Backup config
    local backup_file="${BACKUP_DIR}/config_$(date +%Y%m%d_%H%M%S).json"
    cp "$XRAY_CONFIG" "$backup_file"
    
    # Remove #LOCKED_ prefix (handle multiple #LOCKED_ if exists)
    sed -i "s/^#LOCKED_\+\(.*${user}.*\)/\1/g" "$XRAY_CONFIG"
    
    # Get UUID and unlock it too
    local uuid=$(grep "email.*${user}" "$XRAY_CONFIG" | grep -oP '(?<="id": ")[^"]+' | head -1)
    if [ -z "$uuid" ]; then
        uuid=$(grep -B 2 "email.*${user}" "$XRAY_CONFIG" | grep "password" | grep -oP '(?<="password": ")[^"]+' | head -1)
    fi
    
    if [ ! -z "$uuid" ]; then
        sed -i "s/^#LOCKED_\+\(.*${uuid}.*\)/\1/g" "$XRAY_CONFIG"
    fi
    
    # Restart XRAY
    systemctl restart xray > /dev/null 2>&1
    sleep 2
    
    if systemctl is-active --quiet xray; then
        log_msg "${GREEN}[UNBLOCKED]${NC} User '${user}' unblocked, XRAY restarted successfully"
        return 0
    else
        log_msg "${RED}[CRITICAL]${NC} XRAY failed to start! Restoring backup..."
        cp "$backup_file" "$XRAY_CONFIG"
        systemctl restart xray
        return 1
    fi
}

build_uuid_map() {
    > "$USER_UUID_MAP"
    
    grep -E '"email"' "$XRAY_CONFIG" | grep -v '#LOCKED_' | while read line; do
        email=$(echo "$line" | grep -oP '(?<="email": ")[^"]+')
        [ ! -z "$email" ] && echo "$email" >> "$USER_UUID_MAP"
    done
    
    sort -u "$USER_UUID_MAP" -o "$USER_UUID_MAP"
}

track_ip_sessions() {
    > "$IP_SESSIONS"
    
    local xray_ports=$(netstat -tlnp 2>/dev/null | grep xray | awk '{print $4}' | cut -d: -f2 | grep -v '^10085$')
    
    for port in $xray_ports; do
        netstat -tn 2>/dev/null | grep ":${port} " | grep ESTABLISHED | awk '{print $5}' | cut -d: -f1 | while read ip; do
            [ "$ip" = "127.0.0.1" ] && continue
            [ -z "$ip" ] && continue
            echo "${port}:${ip}:$(date +%s)" >> "$IP_SESSIONS"
        done
    done
}

monitor_and_enforce() {
    log_msg "${GREEN}[START]${NC} XRAY IP Limit Monitor v3.1"
    
    build_uuid_map
    
    local current_time=$(date +%s)
    if [ -s "$LOCK_FILE" ]; then
        while IFS=: read -r user lock_until; do
            if [ "$current_time" -ge "$lock_until" ]; then
                unblock_user_in_xray "$user"
                sed -i "/^${user}:/d" "$LOCK_FILE"
                log_msg "${GREEN}[AUTO-UNLOCK]${NC} User '${user}' automatically unlocked"
            fi
        done < "$LOCK_FILE"
    fi
    
    track_ip_sessions
    
    if [ -s "$USER_UUID_MAP" ]; then
        cat "$USER_UUID_MAP" | while read email; do
            is_user_locked "$email" && continue
            
            local ip_count=$(cat "$IP_SESSIONS" | cut -d: -f2 | sort -u | wc -l)
            local limit=$(get_user_limit "$email")
            
            if [ "$ip_count" -gt "$limit" ]; then
                log_msg "${RED}[ALERT]${NC} User '${email}' may have ${ip_count} IPs (limit: ${limit})"
            fi
        done
    fi
    
    log_msg "${BLUE}[INFO]${NC} Monitoring cycle completed"
}

set_user_limit() {
    local user="$1"
    local max_ip="$2"
    local lock_minutes="$3"
    
    sed -i "/^${user}:/d" "$LIMIT_CONFIG"
    echo "${user}:${max_ip}:${lock_minutes}" >> "$LIMIT_CONFIG"
    
    echo -e "${GREEN}✓${NC} Limit set for user '${user}': Max ${max_ip} IPs, Lock ${lock_minutes} minutes"
    log_msg "[CONFIG] Set limit for '${user}': max_ip=${max_ip}, lock=${lock_minutes}min"
}

show_status() {
    echo -e "\n${GREEN}╔════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║    XRAY IP Limiter Status v3.1        ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════╝${NC}\n"
    
    echo -e "${YELLOW}📋 User Limits Configuration:${NC}"
    if [ -s "$LIMIT_CONFIG" ]; then
        cat "$LIMIT_CONFIG" | while IFS=: read -r user max_ip lock_min; do
            echo -e "  ${BLUE}▸${NC} ${user}: Max ${GREEN}${max_ip}${NC} IPs, Lock ${RED}${lock_min}${NC} minutes"
        done
    else
        echo -e "  ${YELLOW}No custom limits set${NC}"
    fi
    
    echo -e "\n${YELLOW}🔒 Currently Locked Users:${NC}"
    if [ -s "$LOCK_FILE" ]; then
        cat "$LOCK_FILE" | while IFS=: read -r user lock_until; do
            local remaining=$((lock_until - $(date +%s)))
            if [ $remaining -gt 0 ]; then
                local mins=$((remaining / 60))
                local secs=$((remaining % 60))
                echo -e "  ${RED}▸${NC} ${user}: Unlocks in ${RED}${mins}m ${secs}s${NC}"
            fi
        done
    else
        echo -e "  ${GREEN}✓ No users locked${NC}"
    fi
    
    echo -e "\n${YELLOW}👥 Active Users:${NC}"
    build_uuid_map
    if [ -s "$USER_UUID_MAP" ]; then
        local total=$(cat "$USER_UUID_MAP" | wc -l)
        local locked=$(grep -c '#LOCKED_.*email' "$XRAY_CONFIG" 2>/dev/null || echo 0)
        echo -e "  ${GREEN}▸${NC} Total users: ${total}"
        echo -e "  ${RED}▸${NC} Locked users: ${locked}"
        echo -e "  ${GREEN}▸${NC} Active connections: $(ss -tn 2>/dev/null | grep xray | grep ESTAB | wc -l)"
    fi
    
    echo ""
}

list_users() {
    echo -e "\n${GREEN}📋 Registered XRAY Users:${NC}\n"
    build_uuid_map
    
    cat "$USER_UUID_MAP" | while read email; do
        local limit=$(get_user_limit "$email")
        local locked=""
        is_user_locked "$email" && locked="${RED}[LOCKED]${NC}"
        
        local blocked_in_config=""
        grep -q "#LOCKED_.*${email}" "$XRAY_CONFIG" && blocked_in_config="${YELLOW}[BLOCKED IN CONFIG]${NC}"
        
        echo -e "  ${BLUE}▸${NC} ${email} ${locked} ${blocked_in_config}"
        echo -e "    Limit: ${GREEN}${limit}${NC} IPs"
        echo ""
    done
}

case "$1" in
    monitor) monitor_and_enforce ;;
    set)
        [ -z "$2" ] || [ -z "$3" ] || [ -z "$4" ] && echo "Usage: $0 set <username> <max_ip> <lock_minutes>" && exit 1
        set_user_limit "$2" "$3" "$4"
        ;;
    unlock)
        [ -z "$2" ] && echo "Usage: $0 unlock <username>" && exit 1
        unblock_user_in_xray "$2"
        sed -i "/^${2}:/d" "$LOCK_FILE"
        echo -e "${GREEN}✓${NC} User '${2}' unlocked"
        ;;
    lock)
        [ -z "$2" ] && echo "Usage: $0 lock <username>" && exit 1
        lock_user "$2"
        block_user_in_xray "$2"
        echo -e "${RED}✓${NC} User '${2}' locked"
        ;;
    status) show_status ;;
    list) list_users ;;
    *)
        echo -e "${GREEN}XRAY IP Limiter v3.1${NC} - Production Ready"
        echo ""
        echo "Usage: $0 {monitor|set|lock|unlock|status|list}"
        echo ""
        echo "Commands:"
        echo "  ${BLUE}monitor${NC}              - Run monitoring and auto-enforcement"
        echo "  ${BLUE}set${NC} USER IP MINS     - Set custom limit for user"
        echo "  ${BLUE}lock${NC} USER            - Manually lock user"
        echo "  ${BLUE}unlock${NC} USER          - Manually unlock user"
        echo "  ${BLUE}status${NC}               - Show current status"
        echo "  ${BLUE}list${NC}                 - List all users with limits"
        exit 1
        ;;
esac

exit 0
